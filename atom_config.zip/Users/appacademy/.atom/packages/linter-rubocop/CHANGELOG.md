# 0.2.1

### New Features

* Support rspec syntax [#12](https://github.com/AtomLinter/linter-rubocop/pull/12)

# 0.2.0

### New Features

* Run linter under `source.ruby.rails`, with `-R` flag [#5](https://github.com/AtomLinter/linter-rubocop/issues/5)
