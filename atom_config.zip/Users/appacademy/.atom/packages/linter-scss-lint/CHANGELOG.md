## 0.0.9
* Add support for the .scss-lint.yml config file
