# Atom expand-selection-to-quotes

Expands selections in the Atom editor to single or double quotes.

The default keybinding is Ctrl+'.

This project is based on the awesome work of kek in [sublime-expand-selection-to-quotes](https://github.com/kek/sublime-expand-selection-to-quotes).

## Known Issues
* Currently only supports one cursor.
* It assumes that the type of quote to the left of the cursor is the one we want, which is stupid and not always true.

## Release Notes
0.1.0: Initial release.
