# Change log

https://github.com/thomaslindstrom/color-picker

## v1.4.4
- Fix a bug where clicking a color pointer that lead to the active file didn't scroll to the definition

## v1.4.3
- Remove `event-kit` dependency as it took a long time to activate
- Tidy up some bits of code

## v1.4.2
- Patch package. Uploading v.1.4.1 failed

## v1.4.1
- Close color picker on editor scroll
- Set up a `CHANGELOG.md`
